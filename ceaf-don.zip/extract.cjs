const extract = require('extract-zip');
const path = require('path');
const fs = require('fs');

async function main() {
  try {
    // The zip file is in /app/applet/ceafgit.zip
    await extract('/app/applet/ceafgit.zip', { dir: '/app/applet/ceafgit_extracted' });
    console.log('Extraction complete');
  } catch (err) {
    console.error('Error:', err);
  }
}
main();
